/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50737
 Source Host           : localhost:3306
 Source Schema         : questionnaire

 Target Server Type    : MySQL
 Target Server Version : 50737
 File Encoding         : 65001

 Date: 01/12/2023 16:57:55
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '姓名',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色标识',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '电话',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '管理员' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, 'admin', 'admin', '管理员', 'http://localhost:9090/files/1697438073596-avatar.png', 'ADMIN', '13877889988', 'aaa@xm.com');

-- ----------------------------
-- Table structure for answer
-- ----------------------------
DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `question_id` int(11) NULL DEFAULT NULL COMMENT '题目ID',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `page_id` int(11) NULL DEFAULT NULL COMMENT '问卷ID',
  `no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '调查编号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 36 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '答题表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of answer
-- ----------------------------
INSERT INTO `answer` VALUES (25, 26, '是的', 12, '1701418446171');
INSERT INTO `answer` VALUES (26, 27, '[\"是的\",\"对的\"]', 12, '1701418446171');
INSERT INTO `answer` VALUES (27, 28, '都很骚', 12, '1701418446171');
INSERT INTO `answer` VALUES (28, 29, '333', 12, '1701418446171');
INSERT INTO `answer` VALUES (29, 30, '2222', 12, '1701418446171');
INSERT INTO `answer` VALUES (30, 26, '不是', 12, '1701419373126');
INSERT INTO `answer` VALUES (31, 27, '[\"yes\",\"对的\"]', 12, '1701419373126');
INSERT INTO `answer` VALUES (32, 28, '都很帅', 12, '1701419373126');
INSERT INTO `answer` VALUES (33, 29, '444', 12, '1701419373126');
INSERT INTO `answer` VALUES (34, 30, '33333', 12, '1701419373126');
INSERT INTO `answer` VALUES (35, 41, '23131231', 15, '1701420434769');

-- ----------------------------
-- Table structure for logs
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `operation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作',
  `username` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作人',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '类型',
  `ip` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT 'IP地址',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 69 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '日志表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of logs
-- ----------------------------
INSERT INTO `logs` VALUES (3, '注册', '小哈哈', '注册', '127.0.0.1', '2023-11-30 10:01:58');
INSERT INTO `logs` VALUES (4, '登录', 'admin', '登录', '127.0.0.1', '2023-11-30 10:18:52');
INSERT INTO `logs` VALUES (5, '登录', 'admin', '登录', '127.0.0.1', '2023-11-30 10:22:39');
INSERT INTO `logs` VALUES (6, '注册', 'bbb', '注册', '127.0.0.1', '2023-11-30 10:26:45');
INSERT INTO `logs` VALUES (7, '登录', 'bbb', '登录', '127.0.0.1', '2023-11-30 10:26:52');
INSERT INTO `logs` VALUES (8, '创建问卷【bbb测试】', 'bbb', '新增', '127.0.0.1', '2023-11-30 10:27:17');
INSERT INTO `logs` VALUES (9, '修改问卷【bbb测试1】', 'bbb', '修改', '127.0.0.1', '2023-11-30 10:27:30');
INSERT INTO `logs` VALUES (10, '删除问卷【bbb测试1】', 'bbb', '删除', '127.0.0.1', '2023-11-30 10:27:38');
INSERT INTO `logs` VALUES (11, '登录', 'admin', '登录', '127.0.0.1', '2023-11-30 11:24:26');
INSERT INTO `logs` VALUES (12, '修改问卷【大学生消费情况调查】', 'admin', '修改', '127.0.0.1', '2023-11-30 11:24:40');
INSERT INTO `logs` VALUES (13, '修改问卷【大学生恋爱观调查】', 'admin', '修改', '127.0.0.1', '2023-11-30 11:24:44');
INSERT INTO `logs` VALUES (14, '修改问卷【大学生网购调查问卷】', 'admin', '修改', '127.0.0.1', '2023-11-30 11:24:49');
INSERT INTO `logs` VALUES (15, '登录', 'admin', '登录', '127.0.0.1', '2023-12-01 09:37:26');
INSERT INTO `logs` VALUES (16, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 09:37:33');
INSERT INTO `logs` VALUES (17, '登录', 'admin', '登录', '127.0.0.1', '2023-12-01 09:38:54');
INSERT INTO `logs` VALUES (18, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 09:39:02');
INSERT INTO `logs` VALUES (19, '修改问卷【大学生学习情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 10:36:01');
INSERT INTO `logs` VALUES (20, '创建问卷【大学生学习情况调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 10:36:01');
INSERT INTO `logs` VALUES (21, '复制新的问卷【大学生学习情况调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 10:36:01');
INSERT INTO `logs` VALUES (22, '登录', 'admin', '登录', '127.0.0.1', '2023-12-01 11:00:02');
INSERT INTO `logs` VALUES (23, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 11:02:26');
INSERT INTO `logs` VALUES (24, '创建问卷【大学生训练调查】', 'aaa', '新增', '127.0.0.1', '2023-12-01 11:08:06');
INSERT INTO `logs` VALUES (25, '登录', 'admin', '登录', '127.0.0.1', '2023-12-01 11:08:20');
INSERT INTO `logs` VALUES (26, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 11:08:34');
INSERT INTO `logs` VALUES (27, '修改问卷【大学生训练调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 11:09:16');
INSERT INTO `logs` VALUES (28, '删除问卷【大学生学习情况调查-拷贝】', 'aaa', '删除', '127.0.0.1', '2023-12-01 12:24:50');
INSERT INTO `logs` VALUES (29, '修改问卷【大学生学习情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 12:28:17');
INSERT INTO `logs` VALUES (30, '创建问卷【大学生学习情况调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 12:28:17');
INSERT INTO `logs` VALUES (31, '复制新的问卷【大学生学习情况调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 12:28:17');
INSERT INTO `logs` VALUES (32, '删除问卷【大学生学习情况调查-拷贝】', 'aaa', '删除', '127.0.0.1', '2023-12-01 12:29:04');
INSERT INTO `logs` VALUES (33, '删除问卷【大学生训练调查】', 'aaa', '删除', '127.0.0.1', '2023-12-01 12:30:25');
INSERT INTO `logs` VALUES (34, '修改问卷【大学生学习情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 12:31:52');
INSERT INTO `logs` VALUES (35, '创建问卷【大学生学习情况调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 12:31:52');
INSERT INTO `logs` VALUES (36, '复制新的问卷【大学生学习情况调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 12:31:53');
INSERT INTO `logs` VALUES (37, '修改问卷【大学生学习情况调查-拷贝】', 'aaa', '修改', '127.0.0.1', '2023-12-01 12:38:40');
INSERT INTO `logs` VALUES (38, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 14:14:39');
INSERT INTO `logs` VALUES (39, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 14:32:55');
INSERT INTO `logs` VALUES (40, '修改问卷【大学生学习情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 14:34:19');
INSERT INTO `logs` VALUES (41, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 16:34:40');
INSERT INTO `logs` VALUES (42, '修改问卷【大学生学习情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:39:30');
INSERT INTO `logs` VALUES (43, '创建问卷【大学生学习情况调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 16:39:30');
INSERT INTO `logs` VALUES (44, '复制新的问卷【大学生学习情况调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 16:39:30');
INSERT INTO `logs` VALUES (45, '修改问卷【大学生就业意向调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:39:50');
INSERT INTO `logs` VALUES (46, '创建问卷【大学生就业意向调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 16:39:50');
INSERT INTO `logs` VALUES (47, '复制新的问卷【大学生就业意向调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 16:39:50');
INSERT INTO `logs` VALUES (48, '修改问卷【大学生消费情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:42:12');
INSERT INTO `logs` VALUES (49, '创建问卷【大学生消费情况调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 16:42:12');
INSERT INTO `logs` VALUES (50, '复制新的问卷【大学生消费情况调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 16:42:12');
INSERT INTO `logs` VALUES (51, '修改问卷【大学生学习情况调查】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:42:26');
INSERT INTO `logs` VALUES (52, '创建问卷【大学生学习情况调查-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 16:42:26');
INSERT INTO `logs` VALUES (53, '复制新的问卷【大学生学习情况调查-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 16:42:26');
INSERT INTO `logs` VALUES (54, '修改问卷【大学生学习情况调查11111】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:42:36');
INSERT INTO `logs` VALUES (55, '修改问卷【大学生消费情况调查-拷贝】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:43:37');
INSERT INTO `logs` VALUES (56, '修改问卷【大学生消费情况调查-拷贝】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:45:34');
INSERT INTO `logs` VALUES (57, '修改问卷【大学生消费情况调查单选】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:45:50');
INSERT INTO `logs` VALUES (58, '修改问卷【大学生消费情况调查单选】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:45:52');
INSERT INTO `logs` VALUES (59, '创建问卷【大学生消费情况调查单选-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 16:45:52');
INSERT INTO `logs` VALUES (60, '复制新的问卷【大学生消费情况调查单选-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 16:45:52');
INSERT INTO `logs` VALUES (61, '删除问卷【大学生消费情况调查单选-拷贝】', 'aaa', '删除', '127.0.0.1', '2023-12-01 16:45:56');
INSERT INTO `logs` VALUES (62, '修改问卷【大学生学习情况调查-拷贝】', 'aaa', '修改', '127.0.0.1', '2023-12-01 16:47:28');
INSERT INTO `logs` VALUES (63, '创建问卷【大学生学习情况调查-拷贝-拷贝】', 'aaa', '新增', '127.0.0.1', '2023-12-01 16:47:28');
INSERT INTO `logs` VALUES (64, '复制新的问卷【大学生学习情况调查-拷贝-拷贝】', 'aaa', '复制', '127.0.0.1', '2023-12-01 16:47:28');
INSERT INTO `logs` VALUES (65, '删除问卷【大学生学习情况调查-拷贝-拷贝】', 'aaa', '删除', '127.0.0.1', '2023-12-01 16:47:31');
INSERT INTO `logs` VALUES (66, '登录', 'admin', '登录', '127.0.0.1', '2023-12-01 16:47:43');
INSERT INTO `logs` VALUES (67, '登录', 'aaa', '登录', '127.0.0.1', '2023-12-01 16:48:29');
INSERT INTO `logs` VALUES (68, '登录', 'admin', '登录', '127.0.0.1', '2023-12-01 16:48:40');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '标题',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建时间',
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '公告信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (1, '今天系统正式上线，开始内测', '今天系统正式上线，开始内测', '2023-09-05', 'admin');
INSERT INTO `notice` VALUES (2, '所有功能都已完成，可以正常使用', '所有功能都已完成，可以正常使用', '2023-09-05', 'admin');
INSERT INTO `notice` VALUES (3, '今天天气很不错，可以出去一起玩了', '今天天气很不错，可以出去一起玩了', '2023-09-05', 'admin');

-- ----------------------------
-- Table structure for pages
-- ----------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '模板名称',
  `descr` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '模板介绍',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '封面图',
  `count` int(11) NULL DEFAULT 0 COMMENT '使用次数',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '创建人ID',
  `create_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '创建时间',
  `open` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '否' COMMENT '是否公开',
  `saved` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT '否' COMMENT '是否发布',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '问卷表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of pages
-- ----------------------------
INSERT INTO `pages` VALUES (2, '大学生就业意向调查', '调查大学生就业意向', 'http://localhost:9090/files/1701226084703-student-849822_1920.jpg', 1, 1, '2023-11-29 10:48:07', '是', '是');
INSERT INTO `pages` VALUES (3, '大学生兼职情况调查', '大学生兼职情况调查', 'http://localhost:9090/files/1701308897206-writing-923882_1920.jpg', 0, 7, '2023-11-30 09:48:20', '是', '是');
INSERT INTO `pages` VALUES (5, '大学生网购调查问卷', '大学生网购调查问卷', 'http://localhost:9090/files/1701314688716-hands-820272_1920.jpg', 0, 7, '2023-11-30 09:48:20', '是', '是');
INSERT INTO `pages` VALUES (6, '大学生恋爱观调查', '大学生恋爱观调查', 'http://localhost:9090/files/1701314683937-arm-1284248_1920.jpg', 0, 7, '2023-11-30 09:48:20', '是', '是');
INSERT INTO `pages` VALUES (7, '大学生消费情况调查', '大学生消费情况调查', 'http://localhost:9090/files/1701314679220-laptop-3196481_1920.jpg', 1, 7, '2023-11-30 09:48:20', '是', '是');
INSERT INTO `pages` VALUES (8, '大学生学习情况调查', '大学生学习情况调查', 'http://localhost:9090/files/1701308897206-writing-923882_1920.jpg', 4, 7, '2023-11-30 09:48:20', '是', '是');
INSERT INTO `pages` VALUES (12, '大学生学习情况调查', '大学生学习情况调查', 'http://localhost:9090/files/1701308897206-writing-923882_1920.jpg', 1, 1, '2023-12-01 12:31:52', '否', '否');
INSERT INTO `pages` VALUES (13, '大学生学习情况调查11111', '大学生学习情况调查', 'http://localhost:9090/files/1701308897206-writing-923882_1920.jpg', 0, 1, '2023-12-01 16:39:30', '否', '否');
INSERT INTO `pages` VALUES (14, '大学生就业意向调查-拷贝', '调查大学生就业意向', 'http://localhost:9090/files/1701226084703-student-849822_1920.jpg', 0, 1, '2023-12-01 16:39:50', '否', '否');
INSERT INTO `pages` VALUES (15, '大学生消费情况调查单选', '大学生消费情况调查', 'http://localhost:9090/files/1701314679220-laptop-3196481_1920.jpg', 1, 1, '2023-12-01 16:42:12', '否', '是');
INSERT INTO `pages` VALUES (16, '大学生学习情况调查-拷贝', '大学生学习情况调查', 'http://localhost:9090/files/1701308897206-writing-923882_1920.jpg', 1, 1, '2023-12-01 16:42:26', '否', '否');

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '题目名称',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '题目类型',
  `page_id` int(11) NULL DEFAULT NULL COMMENT '问卷ID',
  `user_id` int(11) NULL DEFAULT NULL COMMENT '创建人ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '题目表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of question
-- ----------------------------
INSERT INTO `question` VALUES (4, '今天玩耍了吗', '单选题', 2, 1);
INSERT INTO `question` VALUES (5, '今天游泳了吗', '单选题', 2, 1);
INSERT INTO `question` VALUES (6, '小哥哥真的很骚', '填空题', 3, 1);
INSERT INTO `question` VALUES (7, '小武哥哥真的很帅', '多选题', 3, 1);
INSERT INTO `question` VALUES (8, '小武哥哥真的很骚吗', '单选题', 8, 1);
INSERT INTO `question` VALUES (9, '小青哥哥真的在直播吗', '多选题', 8, 1);
INSERT INTO `question` VALUES (10, '青哥哥和武哥哥哪个更骚', '填空题', 8, 1);
INSERT INTO `question` VALUES (11, '小武哥哥真的很骚吗? 你觉得呢？', '单选题', 9, 1);
INSERT INTO `question` VALUES (12, '大学生学习情况调查-拷贝', '多选题', 9, 1);
INSERT INTO `question` VALUES (26, '小武哥哥真的很骚吗', '单选题', 12, 1);
INSERT INTO `question` VALUES (27, '小青哥哥真的在直播吗', '多选题', 12, 1);
INSERT INTO `question` VALUES (28, '青哥哥和武哥哥哪个更骚', '填空题', 12, 1);
INSERT INTO `question` VALUES (29, '222', '单选题', 12, 1);
INSERT INTO `question` VALUES (30, '1223133', '单选题', 12, 1);
INSERT INTO `question` VALUES (31, '小武哥哥真的很骚吗', '单选题', 13, 1);
INSERT INTO `question` VALUES (32, '小青哥哥真的在直播吗', '多选题', 13, 1);
INSERT INTO `question` VALUES (33, '青哥哥和武哥哥哪个更骚', '填空题', 13, 1);
INSERT INTO `question` VALUES (34, '222', '单选题', 13, 1);
INSERT INTO `question` VALUES (35, '1223133', '单选题', 13, 1);
INSERT INTO `question` VALUES (36, '今天玩耍了吗', '单选题', 14, 1);
INSERT INTO `question` VALUES (37, '今天游泳了吗', '单选题', 14, 1);
INSERT INTO `question` VALUES (38, '小武哥哥真的很骚吗', '单选题', 16, 1);
INSERT INTO `question` VALUES (39, '小青哥哥真的在直播吗', '多选题', 16, 1);
INSERT INTO `question` VALUES (40, '青哥哥和武哥哥哪个更骚', '填空题', 16, 1);
INSERT INTO `question` VALUES (41, '112313123213213', '单选题', 15, 1);

-- ----------------------------
-- Table structure for question_item
-- ----------------------------
DROP TABLE IF EXISTS `question_item`;
CREATE TABLE `question_item`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '内容',
  `question_id` int(11) NULL DEFAULT NULL COMMENT '题目ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 68 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '题目内容表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of question_item
-- ----------------------------
INSERT INTO `question_item` VALUES (3, '4444', 4);
INSERT INTO `question_item` VALUES (4, '33333', 4);
INSERT INTO `question_item` VALUES (5, '66666', 4);
INSERT INTO `question_item` VALUES (6, '111111', 5);
INSERT INTO `question_item` VALUES (7, '222222', 5);
INSERT INTO `question_item` VALUES (8, '是的', 8);
INSERT INTO `question_item` VALUES (9, '不是', 8);
INSERT INTO `question_item` VALUES (10, '是的', 9);
INSERT INTO `question_item` VALUES (11, 'yes', 9);
INSERT INTO `question_item` VALUES (12, '对的', 9);
INSERT INTO `question_item` VALUES (13, '是的哈哈哈', 11);
INSERT INTO `question_item` VALUES (14, '不是噢噢噢', 11);
INSERT INTO `question_item` VALUES (15, '是的', 12);
INSERT INTO `question_item` VALUES (16, 'yes', 12);
INSERT INTO `question_item` VALUES (17, '对的', 12);
INSERT INTO `question_item` VALUES (18, '2222', 18);
INSERT INTO `question_item` VALUES (19, '3333', 19);
INSERT INTO `question_item` VALUES (21, 'nono', 11);
INSERT INTO `question_item` VALUES (31, '是的', 26);
INSERT INTO `question_item` VALUES (32, '不是', 26);
INSERT INTO `question_item` VALUES (33, '是的', 27);
INSERT INTO `question_item` VALUES (34, 'yes', 27);
INSERT INTO `question_item` VALUES (35, '对的', 27);
INSERT INTO `question_item` VALUES (36, '333', 29);
INSERT INTO `question_item` VALUES (37, '444', 29);
INSERT INTO `question_item` VALUES (38, '2222', 30);
INSERT INTO `question_item` VALUES (39, '33333', 30);
INSERT INTO `question_item` VALUES (40, '是的', 31);
INSERT INTO `question_item` VALUES (41, '不是', 31);
INSERT INTO `question_item` VALUES (42, '是的', 32);
INSERT INTO `question_item` VALUES (43, 'yes', 32);
INSERT INTO `question_item` VALUES (44, '对的', 32);
INSERT INTO `question_item` VALUES (45, '333', 34);
INSERT INTO `question_item` VALUES (46, '444', 34);
INSERT INTO `question_item` VALUES (47, '2222', 35);
INSERT INTO `question_item` VALUES (48, '33333', 35);
INSERT INTO `question_item` VALUES (49, '4444', 36);
INSERT INTO `question_item` VALUES (50, '33333', 36);
INSERT INTO `question_item` VALUES (51, '66666', 36);
INSERT INTO `question_item` VALUES (52, '111111', 37);
INSERT INTO `question_item` VALUES (53, '222222', 37);
INSERT INTO `question_item` VALUES (54, '是的', 38);
INSERT INTO `question_item` VALUES (55, '不是', 38);
INSERT INTO `question_item` VALUES (56, '是的', 39);
INSERT INTO `question_item` VALUES (57, 'yes', 39);
INSERT INTO `question_item` VALUES (58, '对的', 39);
INSERT INTO `question_item` VALUES (59, '23131231', 41);
INSERT INTO `question_item` VALUES (60, '3123213213', 41);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '密码',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '姓名',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '头像',
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '角色标识',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '电话',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL COMMENT '邮箱',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci COMMENT = '用户' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, 'aaa', '123', '青哥哥', 'http://localhost:9090/files/1701223537611-微信截图_20231018172251.png', 'USER', '13877889966', 'aaa1@xm.com');
INSERT INTO `user` VALUES (7, 'abc', '123', 'abc', NULL, 'USER', NULL, NULL);
INSERT INTO `user` VALUES (9, 'fff', '123', 'fff', 'http://localhost:9090/files/1701145016389-微信截图_20231018172512.png', 'USER', NULL, NULL);
INSERT INTO `user` VALUES (10, 'ccc', '123', 'ccc', NULL, 'USER', NULL, NULL);
INSERT INTO `user` VALUES (11, 'bbb', '123', 'bbb', NULL, 'USER', NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
