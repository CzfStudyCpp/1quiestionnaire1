<template>
  <div class="main-content">
    <el-card>
      <div slot="header">
        <span style="font-size: 20px">客服中心</span>
      </div>
      <div style="display: flex; grid-gap: 50px">
        <div style="width: 200px; line-height: 28px">
          <div>客服服务时间：</div>
          <div>08:30-12:00</div>
          <div>12:00-14:00（值班）</div>
          <div>14:00-18:00</div>
          <div style="margin-bottom: 10px">18:00-21:00（值班）</div>
          <div>内容安全服务时间：</div>
          <div>07:00-00:00（工作日）</div>
          <div>08:00-00:00（节假日）</div>
        </div>

        <div>
          <div style="font-size: 18px; font-weight: bold; margin-bottom: 20px">售前咨询</div>
          <div style="line-height: 28px">
           <div> 1、由于客服资源有限，我们仅受理由于网站本身导致的问题。</div>
           <div> 2、使用过程任何问题请咨询电话：12345678</div>
          </div>
        </div>

        <div>
          <div style="font-size: 18px; font-weight: bold; margin-bottom: 20px">客户投诉</div>
          <div style="line-height: 28px">
            <div> qq:3319348123</div>
            <div>通过联系该qq进行反馈</div>
          </div>
        </div>

      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  name: "Contactus",
  data() {
    return {}
  },
  created() {

  },
  methods: {}
}
</script>

<style scoped>

</style>