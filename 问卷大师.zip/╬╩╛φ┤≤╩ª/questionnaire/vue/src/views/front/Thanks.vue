<template>
  <div class="main-content">
    <div style="min-height: 80vh; display: flex; align-items: center; justify-content: center; flex-direction: column">
      <div style="font-size: 50px; margin-bottom: 20px; color: #409EFF">感谢您的参与！祝您生活愉快~</div>
      <div><a href="/front/home" style="font-size: 20px">返回首页</a></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Thanks",
  data() {
    return {}
  },
  created() {

  },
  methods: {}
}
</script>

<style scoped>

</style>